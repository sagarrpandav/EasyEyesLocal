# control-panel

**BETA DO NOT USE.**

Scientist-facing web-app accepts an experiment table and generates the necessary files for an online experiment, all from within the browser.
